This code is indended to go alongside the blog post "Programming Tensor Cores in CUDA 9" here: https://devblogs.nvidia.com/parallelforall/programming-tensor-cores-cuda-9/

The code is not written for performance but instead to demonstrate the API. For a high performance GEMM using Tensor cores please use cuBLAS.
