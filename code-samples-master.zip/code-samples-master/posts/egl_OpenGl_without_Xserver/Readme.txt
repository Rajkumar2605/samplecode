Sample code to create an OpenGL context on top of EGL.


