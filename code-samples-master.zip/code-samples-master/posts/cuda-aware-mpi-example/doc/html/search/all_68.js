var searchData=
[
  ['halotobufferkernel',['HaloToBufferKernel',['../Device_8cu.html#aed8b87392c8fc4c4b5dd2fcd6628c229',1,'Device.cu']]],
  ['host_2ec',['Host.c',['../Host_8c.html',1,'']]]
];
