var searchData=
[
  ['applytopology',['ApplyTopology',['../Host_8c.html#aef3118f365ec96030a022fa17b73fc42',1,'ApplyTopology(int *rank, int size, const int2 *topSize, int *neighbors, int2 *topIndex, MPI_Comm *cartComm):&#160;Host.c'],['../Jacobi_8h.html#aef3118f365ec96030a022fa17b73fc42',1,'ApplyTopology(int *rank, int size, const int2 *topSize, int *neighbors, int2 *topIndex, MPI_Comm *cartComm):&#160;Host.c']]],
  ['atomicmax',['AtomicMax',['../Device_8cu.html#af0933e49e05d5e8ab8f7e81ecc5e57c8',1,'AtomicMax(float *const address, const float value):&#160;Device.cu'],['../Device_8cu.html#a75955732b4cf134509b8a69e2a568c05',1,'AtomicMax(double *const address, const double value):&#160;Device.cu']]]
];
