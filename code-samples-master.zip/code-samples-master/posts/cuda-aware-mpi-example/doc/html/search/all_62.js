var searchData=
[
  ['buffertohalokernel',['BufferToHaloKernel',['../Device_8cu.html#ad7e1d75b01200c655d39f8ca01dbb9f1',1,'Device.cu']]]
];
