To build you will need to download CUB.

To do this run the following command from the code-samples directory:

%> git submodule update --init --recursive
